package com.example.entidades.controller;

import com.example.entidades.dto.EntidadDTO;
import com.example.entidades.services.EntidadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/entidades")
@CrossOrigin(origins = "*")
public class EntidadController {

    private final EntidadService entidadService;

    public EntidadController(EntidadService entidadService) {
        this.entidadService = entidadService;
    }

    @PostMapping
    public ResponseEntity<EntidadDTO> crearEntidad(@RequestBody EntidadDTO entidadDTO) {
        return ResponseEntity.ok(entidadService.crearEntidad(entidadDTO));
    }

    @GetMapping
    public ResponseEntity<List<EntidadDTO>> obtenerTodas() {
        return ResponseEntity.ok(entidadService.obtenerTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntidadDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(entidadService.obtenerPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<EntidadDTO> actualizarEntidad(@PathVariable Long id, @RequestBody EntidadDTO entidadDTO) {
        return ResponseEntity.ok(entidadService.actualizarEntidad(id, entidadDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEntidad(@PathVariable Long id) {
        entidadService.eliminarEntidad(id);
        return ResponseEntity.noContent().build();
    }
}
