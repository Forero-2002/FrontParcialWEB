package com.example.entidades.services;

import com.example.entidades.dto.EntidadDTO;

import java.util.List;

public interface EntidadService {
    EntidadDTO crearEntidad(EntidadDTO entidadDTO);
    EntidadDTO actualizarEntidad(Long id, EntidadDTO entidadDTO);
    void eliminarEntidad(Long id);
    EntidadDTO obtenerPorId(Long id);
    List<EntidadDTO> obtenerTodas();
}
