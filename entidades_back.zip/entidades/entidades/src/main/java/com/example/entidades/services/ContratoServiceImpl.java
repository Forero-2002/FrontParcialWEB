package com.example.entidades.services;

import com.example.entidades.dto.ContratoDTO;
import com.example.entidades.model.Contrato;
import com.example.entidades.model.Entidad;
import com.example.entidades.repository.ContratoRepository;
import com.example.entidades.repository.EntidadRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContratoServiceImpl implements ContratoService {

    private final ContratoRepository contratoRepository;
    private final EntidadRepository entidadRepository;
    private final ModelMapper modelMapper;

    public ContratoServiceImpl(ContratoRepository contratoRepository,
                               EntidadRepository entidadRepository,
                               ModelMapper modelMapper) {
        this.contratoRepository = contratoRepository;
        this.entidadRepository = entidadRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public ContratoDTO crearContrato(Long entidadId, ContratoDTO contratoDTO) {
        Entidad entidad = entidadRepository.findById(entidadId)
                .orElseThrow(() -> new RuntimeException("Entidad no encontrada"));

        Contrato contrato = modelMapper.map(contratoDTO, Contrato.class);
        contrato.setEntidad(entidad);

        return modelMapper.map(contratoRepository.save(contrato), ContratoDTO.class);
    }

    @Override
    public ContratoDTO actualizarContrato(Long id, ContratoDTO contratoDTO) {
        Contrato contrato = contratoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contrato no encontrado"));

        // Actualizar campos
        contrato.setIdentificador(contratoDTO.getIdentificador());
        contrato.setValor(contratoDTO.getValor());
        contrato.setNombreContratante(contratoDTO.getNombreContratante());
        contrato.setDocumentoContratante(contratoDTO.getDocumentoContratante());
        contrato.setNombreContratista(contratoDTO.getNombreContratista());
        contrato.setDocumentoContratista(contratoDTO.getDocumentoContratista());
        contrato.setFechaInicial(contratoDTO.getFechaInicial());
        contrato.setFechaFinal(contratoDTO.getFechaFinal());

        return modelMapper.map(contratoRepository.save(contrato), ContratoDTO.class);
    }

    @Override
    public void eliminarContrato(Long id) {
        contratoRepository.deleteById(id);
    }

    @Override
    public ContratoDTO obtenerPorId(Long id) {
        return contratoRepository.findById(id)
                .map(contrato -> modelMapper.map(contrato, ContratoDTO.class))
                .orElseThrow(() -> new RuntimeException("Contrato no encontrado"));
    }

    @Override
    public List<ContratoDTO> obtenerTodos() {
        return contratoRepository.findAll().stream()
                .map(contrato -> modelMapper.map(contrato, ContratoDTO.class))
                .collect(Collectors.toList());
    }
}
