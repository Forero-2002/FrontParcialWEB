package com.example.entidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntidadesApplication.class, args);
	}

}
