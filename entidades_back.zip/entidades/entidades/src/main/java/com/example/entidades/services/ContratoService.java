package com.example.entidades.services;

import com.example.entidades.dto.ContratoDTO;

import java.util.List;

public interface ContratoService {
    ContratoDTO crearContrato(Long entidadId, ContratoDTO contratoDTO);
    ContratoDTO actualizarContrato(Long id, ContratoDTO contratoDTO);
    void eliminarContrato(Long id);
    ContratoDTO obtenerPorId(Long id);
    List<ContratoDTO> obtenerTodos();
}
