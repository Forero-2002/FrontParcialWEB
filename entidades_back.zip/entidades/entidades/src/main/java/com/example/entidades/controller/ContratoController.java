package com.example.entidades.controller;

import com.example.entidades.dto.ContratoDTO;
import com.example.entidades.services.ContratoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/contratos")
@CrossOrigin(origins = "*")
public class ContratoController {

    private final ContratoService contratoService;

    public ContratoController(ContratoService contratoService) {
        this.contratoService = contratoService;
    }

    @PostMapping("/entidad/{entidadId}")
    public ResponseEntity<ContratoDTO> crearContrato(@PathVariable Long entidadId, @RequestBody ContratoDTO contratoDTO) {
        return ResponseEntity.ok(contratoService.crearContrato(entidadId, contratoDTO));
    }

    @GetMapping
    public ResponseEntity<List<ContratoDTO>> obtenerTodos() {
        return ResponseEntity.ok(contratoService.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ContratoDTO> obtenerPorId(@PathVariable Long id) {
        return ResponseEntity.ok(contratoService.obtenerPorId(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ContratoDTO> actualizarContrato(@PathVariable Long id, @RequestBody ContratoDTO contratoDTO) {
        return ResponseEntity.ok(contratoService.actualizarContrato(id, contratoDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarContrato(@PathVariable Long id) {
        contratoService.eliminarContrato(id);
        return ResponseEntity.noContent().build();
    }
}
