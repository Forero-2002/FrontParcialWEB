package com.example.entidades.services;

import com.example.entidades.dto.EntidadDTO;
import com.example.entidades.model.Entidad;
import com.example.entidades.repository.EntidadRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EntidadServiceImpl implements EntidadService {

    private final EntidadRepository entidadRepository;
    private final ModelMapper modelMapper;

    public EntidadServiceImpl(EntidadRepository entidadRepository, ModelMapper modelMapper) {
        this.entidadRepository = entidadRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public EntidadDTO crearEntidad(EntidadDTO entidadDTO) {
        Entidad entidad = modelMapper.map(entidadDTO, Entidad.class);
        return modelMapper.map(entidadRepository.save(entidad), EntidadDTO.class);
    }

    @Override
    public EntidadDTO actualizarEntidad(Long id, EntidadDTO entidadDTO) {
        Entidad entidad = entidadRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Entidad no encontrada"));
        entidad.setNit(entidadDTO.getNit());
        entidad.setNombre(entidadDTO.getNombre());
        return modelMapper.map(entidadRepository.save(entidad), EntidadDTO.class);
    }

    @Override
    public void eliminarEntidad(Long id) {
        entidadRepository.deleteById(id);
    }

    @Override
    public EntidadDTO obtenerPorId(Long id) {
        return entidadRepository.findById(id)
                .map(entidad -> modelMapper.map(entidad, EntidadDTO.class))
                .orElseThrow(() -> new RuntimeException("Entidad no encontrada"));
    }

    @Override
    public List<EntidadDTO> obtenerTodas() {
        return entidadRepository.findAll().stream()
                .map(entidad -> modelMapper.map(entidad, EntidadDTO.class))
                .collect(Collectors.toList());
    }
}
