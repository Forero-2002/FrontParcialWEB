package com.parcial.web.repositories;

import org.springframework.data.repository.CrudRepository;
import com.parcial.web.entities.Celular;

public interface CelularRepository extends CrudRepository<Celular, Long> {

}
